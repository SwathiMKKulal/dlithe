package col.ele;

import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

@Entity
@Table(name="college")
public class College 
{
	@Id
	@Column(name="college_ID")
	private int colid;
	
	@Column(name="Name")
	private String colname;
	
	@ElementCollection
	@CollectionTable(name="student",joinColumns=@JoinColumn(name="college_id"))
	@Column(name="student_Name")
	private Set<String> students;

	public College(int colid, String colname) {
		super();
		this.colid = colid;
		this.colname = colname;
	}
	
	public College()
	{
		
	}

	public int getColid() {
		return colid;
	}

	public void setColid(int colid) {
		this.colid = colid;
	}

	public String getColname() {
		return colname;
	}

	public void setColname(String colname) {
		this.colname = colname;
	}

	public Set<String> getStudents() {
		return students;
	}

	public void setStudents(Set<String> students) {
		this.students = students;
	}
	
	
}
