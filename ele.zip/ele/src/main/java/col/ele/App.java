package col.ele;

import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory factory = new Configuration().configure().buildSessionFactory();
    	Session session =factory.openSession();
    	session.beginTransaction();
    	College c= null;
    	c=new College(1,"S.S.P.C");
    	session.persist(c);
        Student s1=new Student(1,"Atul",1);
        session.persist(s1);
        Student s2=new Student(2,"Saurabh",1);
        session.persist(s2);
    		    	
       	session.getTransaction().commit();
    	session.refresh(c);
       	
    }
}