package col.ele;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student 
{
	@Id
	@Column(name="student_ID")
	private int studid;
	
	@Column(name="student_Name")
	private String studname;
	
	@Column(name="college_id")
	private int colid;

	public Student(int studid, String studname, int colid) 
	{
		this.studid = studid;
		this.studname = studname;
		this.colid = colid;
	}

	public int getStudid() {
		return studid;
	}

	public void setStudid(int studid) {
		this.studid = studid;
	}

	public String getStudname() {
		return studname;
	}

	public void setStudname(String studname) {
		this.studname = studname;
	}

	public int getColid() {
		return colid;
	}

	public void setColid(int colid) {
		this.colid = colid;
	}
	
	
}
