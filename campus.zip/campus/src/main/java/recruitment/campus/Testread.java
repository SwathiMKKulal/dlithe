package recruitment.campus;
import org.junit.Test;

import junit.framework.Assert;

import junit.framework.TestCase;
import junit.framework.TestSuite;
public class Testread {

	Recruitment c = new Recruitment();
	App a = new App();
	@Test()
	public void testcreate()
	{
		Assert.assertNotNull(c.getCampus());
	}
	
	@Test
	public void testread()
	{
		Assert.assertNotNull(c.getRole());
	}
	
	@Test
	public void testupdate()
	{
		Assert.assertEquals(c.getExpcount(), c);
	}
	
	@Test
	public void delete()
	{
		Assert.assertNull(c.getCampus());
	}
	
	@Test
	public void list()
	{
		Assert.assertNotNull(c);
	}
	
}

   