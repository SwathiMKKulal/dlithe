package j.spring.intrst;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class mainclass {
	

	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		operations p=(operations)app.getBean("savings");
		p.deposite();
		p.interest();
		p=(operations)app.getBean("current");
		p.deposite();
		p.interest();
		/*Trainee te=(Trainee)app.getBean("trainee");
		te.info();
		Trainer tr=(Trainer)app.getBean("trainer");
		tr.info();*/
	}


}
