package j.spring.intrst;

public class savings implements operations {
	private Account sa;

	public Account getSa() {
		return sa;
	}

	public void setSa(Account sa) {
		this.sa = sa;
	}

	public void deposite() {
		// TODO Auto-generated method stub
		double bal=500;
		double s=sa.getAcbl();
		double a=s+bal;
		sa.setAcbl(a);
		System.out.println(sa.toString());
	}

	public void interest() {
		// TODO Auto-generated method stub
		double s=sa.getAcbl();
		double a=s+(s*(5.6/100));
		sa.setAcbl(a);
		System.out.println(sa.toString());
	}
	
	
	
}

	