package j.spring.intrst;

public class Account {

	private String acno;
	private double acbl;
	public String getAcno() {
		return acno;
	}
	public void setAcno(String acno) {
		this.acno = acno;
	}
	public double getAcbl() {
		return acbl;
	}
	public void setAcbl(double acbl) {
		this.acbl = acbl;
	}
	@Override
	public String toString() {
		return "Account [acno=" + acno + ", acbl=" + acbl + "]";
	}
	public Account(String acno, double acbl) {
		super();
		this.acno = acno;
		this.acbl = acbl;
	}
	public Account() {}
}