package j.spring.intrst;

public interface operations {
public void deposite();
public void interest();
}
