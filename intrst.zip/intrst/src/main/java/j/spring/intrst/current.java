package j.spring.intrst;

public class current implements operations {
	
	private Account ca;
	
    public Account getCa() {
		return ca;
	}
	public void setCa(Account ca) {
		this.ca = ca;
	}
	public void deposite()
    {
		double b=500;
		if(b>20000)
		{
			double s=ca.getAcbl();

		    double a1=s+b;
		    ca.setAcbl(a1);
		    System.out.println(ca.toString());
		    }
		else
		{
			System.out.println("minimum deposit has to be 20000");
		}
    }
		    
		 
	public void interest() {
		// TODO Auto-generated method stub
		double s=ca.getAcbl();
		double a=s+(s*(0/100));
		ca.setAcbl(a);
		System.out.println(ca.toString());
	}
	
}