package dlithe.RManagement;


public interface FamilyInterface 
{
	public void CreateFamily();
	public void UpdateFamily();
	public void DeleteFamily();
	public void ListFamily();
}

