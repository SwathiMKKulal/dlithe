package dlithe.RManagement;

public class App 
{
    public static void main( String[] args )
    {
      //  ItemImplementation im = new ItemImplementation();
       // im.CreateItem();
       //im.UpdateItem();
      // im.DeleteItem();
       // im.ListItem();
      // im.end();
    	
    	//RationImplementation rm = new RationImplementation();
    	//rm.CreateRation();
    	//rm.UpdateRation();
    	//rm.DeleteRation();
    	//rm.ListRation();
    	//rm.end();
    	
    	//FamilyImplementation fm = new FamilyImplementation();
    	//fm.CreateFamily();
    	//fm.UpdateFamily();
    	//fm.DeleteFamily();
    	//fm.ListFamily();
    	//fm.end();
    	
    	TransactionImplementation tm = new TransactionImplementation();
    	//tm.CreateTransaction();
    	tm.ListTransaction();
    	tm.end();
    }
}
