package dlithe.RManagement;

public interface ItemInterface 
{
	public void CreateItem();
	public void UpdateItem();
	public void DeleteItem();
	public void ListItem();
}