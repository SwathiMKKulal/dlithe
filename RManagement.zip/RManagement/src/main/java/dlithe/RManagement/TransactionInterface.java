package dlithe.RManagement;

public interface TransactionInterface 
{
	public void Createtransaction();
	public void ListFamily();
}
