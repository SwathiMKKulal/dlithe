package dlithe.RManagement;


public interface RationInterface 
{
	public void CreateRation();
	public void UpdateRation();
	public void DeleteRation();
	public void ListRation();
}

