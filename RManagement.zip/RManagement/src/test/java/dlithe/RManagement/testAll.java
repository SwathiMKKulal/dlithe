package dlithe.RManagement;
    import java.util.ArrayList;
	import java.util.List;

	import org.junit.Assert;
	import org.junit.Test;
	import org.junit.runner.RunWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.Mockito;
	import org.mockito.runners.MockitoJUnitRunner;

	@RunWith(MockitoJUnitRunner.class)
	public class testAll
	{
		List<FamilyModel > tempStock=null; FamilyModel  m1=null,m2=null,m3=null,m4=null;
		public testAll()
		{
			tempStock=new ArrayList<FamilyModel >();
			m1=new FamilyModel(1, "swathi", "blore", "engineer", "12300", "abc@gmail.com", 3);
			m2=new FamilyModel("Note3", "Redmi", 34, 11000);
			m3=new FamilyModel("iPhoneXs", "Apple", 5, 153300);
			m4=new FamilyModel("7Pro","OnePlus",12,53000);
			tempStock.add(m1);tempStock.add(m2);tempStock.add(m3);tempStock.add(m4);
		}
		@InjectMocks
		FamilyImplementation imp=new FamilyImplementation();
		@Mock
		FamilyInterface  dlithe;
		@Test
		public void testCreateFamily()
		{
			List donut=null;
			Mockito.when(dlithe.CreateFamily(tempStock)).thenReturn(true);
			Assert.assertTrue(dlithe.CreateFamily(tempStock));
			Mockito.verify(dlithe).CreateFamily(tempStock);
		}
		@Test(expected=RuntimeException.class)
		public void testUpdateFamily()
		{
			Mockito.when(imp.sum(m1)).thenReturn(imp.sum(m1));
			Assert.assertEquals(dlithe.sum(m1), imp.sum(m1));
			Mockito.verify(dlithe).sum(m1);
		}
		@Test
		public void testDeleteFamily()
		{Mockito.when(dlithe.read(0)).thenReturn(m1);
		Assert.assertEquals(m1, dlithe.read(0));
		}
		@Test
		public void testListFamily()
		{
			List donut=null;
			Mockito.when(dlithe.list()).thenReturn(tempStock);
			Assert.assertEquals(tempStock, dlithe.list());
			Mockito.verify(dlithe).list();
		}
	}

}

