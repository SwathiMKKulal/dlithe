package dlithe.RManagement;

    import java.util.ArrayList;
	import java.util.List;

	import org.junit.Assert;
	import org.junit.Test;
	import org.junit.runner.RunWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.Mockito;
	import org.mockito.runners.MockitoJUnitRunner;

	@RunWith(MockitoJUnitRunner.class)
	public class testItem
	{
		List<ItemModel > tempStock=null;
		ItemModel  m1=null,m2=null,m3=null,m4=null;
		public testItem()
		{
			tempStock=new ArrayList<ItemModel >();
			m1=new ItemModel ("sugar", "100");
			m2=new ItemModel ("rice", "20");
			m3=new ItemModel ("wheat", "10");
			m4=new ItemModel ("oil", "5");
			tempStock.add(m1);tempStock.add(m2);tempStock.add(m3);tempStock.add(m4);
		}
		@InjectMocks
		ItemImplementation imp=new ItemImplementation();
		@Mock
		ItemInterface  dlithe;
		@Test
		
		public void testCreateItem()
		{
			List donut=null;
			Mockito.when(dlithe.createItem(tempStock)).thenReturn(true);
			Assert.assertTrue(dlithe.createItem(tempStock));
			Mockito.verify(dlithe).createItem(tempStock);
		}
		
		
		@Test(expected=RuntimeException.class)
		public void testUpdateItem()
		{
			Mockito.when(imp.UpdateItem(m1)).thenReturn(imp.UpdateItem(m1));
			Assert.assertEquals(dlithe.UpdateItem(m1), imp.UpdateItem(m1));
			Mockito.verify(dlithe).UpdateItem(m1);
		}
		@Test
		public void testDeleteItem()
		{Mockito.when(dlithe.read(0)).thenReturn(m1);
		Assert.assertEquals(m1, dlithe.read(0));
		}
		@Test
		public void testListItem()
		{
			List donut=null;
			Mockito.when(dlithe.ListItem()).thenReturn(tempStock);
			Assert.assertEquals(tempStock, dlithe.ListItem());
			Mockito.verify(dlithe).ListItem();
		}
	}

}
}